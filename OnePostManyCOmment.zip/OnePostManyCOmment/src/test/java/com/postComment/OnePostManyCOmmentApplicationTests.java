package com.postComment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnePostManyCOmmentApplicationTests {

	@Test
	void contextLoads() {
	}

}

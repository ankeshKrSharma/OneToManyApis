package com.postComment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.postComment.entity.Comment;

public interface CommentRepository extends JpaRepository<Comment, Long> {

}

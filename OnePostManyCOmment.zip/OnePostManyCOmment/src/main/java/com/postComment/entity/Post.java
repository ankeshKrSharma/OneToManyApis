package com.postComment.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Post {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long id;
	 private String content;
	 private String description;
	 private String titile;
	 
	 @OneToMany(mappedBy = "post", cascade = CascadeType.ALL,orphanRemoval = true)
	 private List<Comment> comment = new ArrayList<>();


	public Post() {
		super();
	}

	public Post(long id, String content, String description, String titile, List<Comment> comment) {
		super();
		this.id = id;
		this.content = content;
		this.description = description;
		this.titile = titile;
		this.comment = comment;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitile() {
		return titile;
	}

	public void setTitile(String titile) {
		this.titile = titile;
	}

	public List<Comment> getComment() {
		return comment;
	}

	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}
	 
	 
	 
	 
	 
}

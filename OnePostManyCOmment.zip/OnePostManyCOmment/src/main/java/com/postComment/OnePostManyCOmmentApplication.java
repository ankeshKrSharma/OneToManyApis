package com.postComment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnePostManyCOmmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnePostManyCOmmentApplication.class, args);
	}

}

package com.postComment.service;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.postComment.entity.Comment;
import com.postComment.entity.Post;
import com.postComment.payload.CommentDto;
import com.postComment.repository.CommentRepository;
import com.postComment.repository.PostRepository;

@Service
public class CommentServiceImpl implements CommentService {
	
	@Autowired
	private CommentRepository commentRepo;
	@Autowired
	private PostRepository postRepo;

	@Override
	public CommentDto createComment(long postId, CommentDto commentDto) {
		Post post = postRepo.findById(postId).orElseThrow(
				 ()-> new EntityNotFoundException("No record Found")
				);
		
		Comment comment = mapToEntity(commentDto);
		comment.setPost(post);    //ManyToOne
		Comment saveComment = commentRepo.save(comment);
		    CommentDto dto = mapTODto(saveComment);
		
		return dto;
	}
	
	Comment mapToEntity(CommentDto commentDto) {
		Comment comment = new Comment();
		comment.setName(commentDto.getName());
		comment.setEmail(commentDto.getEmail());
		comment.setBody(commentDto.getBody());
		return comment;
		
	}
	
	CommentDto mapTODto(Comment comment) {
		CommentDto dto = new CommentDto(); 
		dto.setId(comment.getId());
		dto.setName(comment.getName());
		dto.setEmail(comment.getEmail());
		dto.setBody(comment.getBody());
		return dto;
		
	}

}

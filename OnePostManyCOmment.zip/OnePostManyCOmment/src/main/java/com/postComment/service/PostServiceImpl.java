package com.postComment.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.postComment.entity.Post;
import com.postComment.payload.PostDto;
import com.postComment.repository.PostRepository;

@Service
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostRepository postRepo;

	@Override
	public PostDto createPost(PostDto postDto) {
		Post post = mapTOEntity(postDto);
		Post newPost = postRepo.save(post);
		PostDto dto = mapToDto(newPost);
		return dto;
	}
	
	
	Post mapTOEntity(PostDto postDto){
		Post post = new Post();
		post.setContent(postDto.getContent());
		post.setDescription(postDto.getDescription());
		post.setTitile(postDto.getTitile());
		return post;
		
	}
	
	PostDto mapToDto(Post post) {
		PostDto dto = new PostDto();
		dto.setId(post.getId());
		dto.setContent(post.getContent());
		dto.setDescription(post.getDescription());
		dto.setTitile(post.getTitile());
		return dto;
		
	}

}

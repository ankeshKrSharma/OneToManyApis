package com.postComment.service;

import com.postComment.payload.CommentDto;

public interface CommentService {
   
	 public CommentDto createComment(long postId, CommentDto commentDto );
}

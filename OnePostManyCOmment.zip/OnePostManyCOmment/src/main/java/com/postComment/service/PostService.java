package com.postComment.service;

import com.postComment.payload.PostDto;

public interface PostService {

	  public PostDto createPost(PostDto postDto);
	
}

package com.postComment.payload;

import java.util.List;

import com.postComment.entity.Comment;

public class PostDto {
	
	 private long id;
	 private String content;
	 private String description;
	 private String titile;
	 private List<Comment> comment ;
	 
	 
	 
	 
	public PostDto() {
		super();
	}
	public PostDto(long id, String content, String description, String titile, List<Comment> comment) {
		super();
		this.id = id;
		this.content = content;
		this.description = description;
		this.titile = titile;
		this.comment = comment;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTitile() {
		return titile;
	}
	public void setTitile(String titile) {
		this.titile = titile;
	}
	public List<Comment> getComment() {
		return comment;
	}
	public void setComment(List<Comment> comment) {
		this.comment = comment;
	}
	 
	 

}

package com.postComment.payload;

import com.postComment.entity.Post;

public class CommentDto {
	
	private long id;
	private String body;
	private String email;
	private String name;
	private Post post;
	
	
	
	public CommentDto() {
		super();
	}
	public CommentDto(long id, String body, String email, String name, Post post) {
		super();
		this.id = id;
		this.body = body;
		this.email = email;
		this.name = name;
		this.post = post;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Post getPost() {
		return post;
	}
	public void setPost(Post post) {
		this.post = post;
	}
	
	

}
